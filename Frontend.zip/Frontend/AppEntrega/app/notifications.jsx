const { Text } = require("react-native");

export default function Notifications() {
    return (
        <>
        </>
    )
}