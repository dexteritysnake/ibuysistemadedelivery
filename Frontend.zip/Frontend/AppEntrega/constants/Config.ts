export default {
  msUpdateInDelivery: 30000,
  msUpdateOffDelivery: 15000,
};
