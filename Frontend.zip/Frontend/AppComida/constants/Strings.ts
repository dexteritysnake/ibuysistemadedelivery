export default {
  token_jwt: "TOKEN_JWT",

  token_jwt2: "TOKEN_JWT2",
  token_location: "token_location",
  wait_interval: 30000,
};
