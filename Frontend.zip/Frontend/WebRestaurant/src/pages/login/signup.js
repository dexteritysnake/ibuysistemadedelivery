import React from "react";

export default function signup() {
  return <>cadastro</>;
}
